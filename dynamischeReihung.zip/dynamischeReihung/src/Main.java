

public class Main {
    public static void main(String[] args) {
        dynArray array = new dynArray();
        array.append(2);
        System.out.println(array.isEmpty());
        array.delete(0);
        System.out.println(array.isEmpty());
    }
}
