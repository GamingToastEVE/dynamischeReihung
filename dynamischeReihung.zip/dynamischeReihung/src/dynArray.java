import java.util.Arrays;

import static java.lang.Integer.parseInt;

public class dynArray {
    public int[] reihung;

    public dynArray() {reihung = new int[0];
    }



    public boolean isEmpty() {
        return reihung.length == 0;
    }

    public int[] append(int value) {
        int[] copyReihung = Arrays.copyOf(reihung, reihung.length + 1);
        copyReihung[reihung.length] = value;
        reihung = copyReihung;
        return reihung;
    }

    public int getItem(int index) {
        return this.reihung[index];
    }

    public int[] delete(int index) {
        int j = 0;
        int[] copyReihung = Arrays.copyOf(this.reihung, this.reihung.length - 1);

        for(int i = 0; i < this.reihung.length; ++i) {
            if (i != index) {
                copyReihung[j] = this.reihung[j];
                ++j;
            }
        }

        this.reihung = copyReihung;
        return copyReihung;
    }
}
